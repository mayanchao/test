fastjson
========

Fast JSON Processor

Documentation
--------
http://code.alibabatech.com/wiki/display/FastJSON/Documentation

Benchmark
--------
https://github.com/eishay/jvm-serializers/wiki
